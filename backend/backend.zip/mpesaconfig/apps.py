from django.apps import AppConfig


class MpesaconfigConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mpesaconfig'
